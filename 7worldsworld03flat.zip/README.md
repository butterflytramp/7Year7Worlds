# 7 Years 7 Worlds — World 03: The Ice Age

**Redesigning our planet — bit by bit, step by step.**

A scroll-led narrative site: from the last glacial maximum, into and through the ice,
out through a whiteout into the Montreal Protocol, then five climate interventions
and eight programmes built in India.

Production build, evolved from the Framer prototype at
`versatile-software-864279.framer.app`.

## Files

| Path | What it is |
|---|---|
| `index.html` | The site. Self-contained — no build step, no dependencies. |
| `mockups.html` | The three fold-1 treatments (Clay / Monument / Expedition) with a live switcher. Kept as a record of the decision; **not** production, and predates the typography pass. |
| `vercel.json` | Clean URLs, cache headers, CSP that permits Google Fonts. |

Everything except the webfonts is inlined, including the graded hero photograph
(a WebP data URI). The only network request the page makes is to
`fonts.googleapis.com` / `fonts.gstatic.com`.

## Deploy

```bash
# 1 · create the repo and push
git init -b main
git add -A
git commit -m "World 03 — The Ice Age"
gh repo create 7worlds-world-03 --private --source=. --remote=origin --push

# 2 · deploy
npx vercel --prod
```

Vercel needs no configuration beyond `vercel.json` — it detects a static site,
serves `index.html` at `/` and `mockups.html` at `/mockups`.

To connect continuous deployment instead, import the repo at
`vercel.com/new` and every push to `main` will ship.

## Notes for whoever picks this up

- **Reduced motion** is a first-class path, not a degradation: the whole story,
  all 9,191 characters of it, is present with the pinned stages unpinned.
- **The India map** is drawn from Natural Earth 1:10m, *India point-of-view*
  edition — it shows Jammu & Kashmir, Ladakh, the Northeast, Andaman & Nicobar
  and Lakshadweep as India depicts them. Do not swap in a generic world dataset.
- **Small type** was audited by measuring rendered contrast against actual
  backgrounds. Every label clears WCAG AA. The rules that keep it there:
  never set text colour with `opacity`, always declare `font-weight` on
  Space Grotesk labels, and give type over the environment a real ground
  (the hero scrim, the beat chips, the caption pools) rather than a blur shadow.
- **Figures are sourced.** Corrections already applied against the prototype:
  Kigali avoids 0.3–0.5 °C (not "up to 0.5"); Ahmedabad averts ~1,190 deaths a
  year (not 2,300); cool roofs measure 2–4 °C for coatings and 7–8 °C for
  engineered modular roofs. Sources are listed in the site footer.
